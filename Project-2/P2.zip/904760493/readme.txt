// ACJ 2016/11/05  
This is the first part of Project. In this week , we implemented LOAD command following the instructions.