<div id="navheader"></div>
<div class="logo_container">
<div class="span4"><a href="index.php"> <img class="schlogo" src="img/ucla.png" /></a></div>
</div>

<div class="clear"></div>
