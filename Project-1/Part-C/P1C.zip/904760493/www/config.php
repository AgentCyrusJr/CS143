<?php 
	//actor表每页的pagesize
	$actors_list_pageSize=6;
	//管理actor表时显示每次上下共多少页
	$actors_list_eachtime_page_count=5;
	//actor表每页的pagesize
	$movies_list_pageSize=6;
	//管理actor表时显示每次上下共多少页
	$movies_list_eachtime_page_count=5;
	//课程表每页的pagesize
	$Cou_list_pageSize=6;
	//课程学生表时显示每次上下共多少页
	$cou_list_eachtime_page_count=5;
	//学生选课信息表每页的pagesize
	$sc_list_pageSize = 6;
	//学生选课表时显示每次上下共多少页
	$sc_list_eachtime_page_count=5;


?>