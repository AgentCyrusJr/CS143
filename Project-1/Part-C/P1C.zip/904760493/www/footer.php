
<div class="container">
<hr/>
<div class="footer">
<div class="link">
<span><a href="#">UCLA.edu</a></span>
<span><a href="#">About</a></span>
<span><a href="#">Contact</a></span>
</div>
<p class="CopyRight">Copyright © 2016. <a href="#">Admin</a></p>
</div>
</div>