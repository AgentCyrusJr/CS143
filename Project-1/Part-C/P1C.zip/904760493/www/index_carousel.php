
  <div id="carousel1" class="carousel slide" data-interval=5000>
  
  	<div class="carousel-inner">
      <div class="item">
      <img src="img/index_pic1.jpg" alt="">
      <div class="carousel-caption">
      <h4>Actors</h4>          
      <p>More than 28000 actors' information</p>
      </div>
      </div>
	  
      <div class="item">
      <img src="img/index_pic2.jpg" alt="">
      <div class="carousel-caption">
      <h4>Movies</h4>
      <p> More than 3000 movies</p>
      </div>
      </div>
	  
      <div class="item  active">
      <img src="img/index_pic3.jpg" alt="">
      <div class="carousel-caption">
      <h4>Directors</h4>
      <p>4311 famous directors</p>
      </div>
      </div>
    </div>
    <a href="#carousel1" data-slide="prev" class="left carousel-control">‹</a>
    <a href="#carousel1" id="nextClick" data-slide="next" class="right carousel-control">›</a>
   </div>

  

